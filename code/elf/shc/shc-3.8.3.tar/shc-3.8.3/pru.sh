#! /bin/sh -x
echo "$0" "$@"
ps $$
ps wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww  $$
cat /proc/$$/cmdline
touch $0.kk
read ENTER
